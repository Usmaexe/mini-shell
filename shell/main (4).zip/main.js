const readline = require("readline");
const os = require("os")

const rl = readline.createInterface({
    input : process.stdin,
    output : process.stdout,
    prompt : "$ "
});



rl.prompt();
rl.on("line", input=>{
    const [cmd, ...args] = input.trim(" ").split(/\s+/);
    switch(cmd){
        case "echo" :
            console.log(args.join(" ") + "\n");
            break;
        case "pwd" :
            console.log(process.cwd());
            break;
        default :
            console.log(`${cmd}: command not found`);
    }
    rl.prompt();
});
    
rl.on("close",()=>{
    console.log("\nBye!");
    process.exit(0);
});