const readline = require("readline");
const os = require("os");
const { exitCode, exit } = require("process");

const rl = readline.createInterface({
    input : process.stdin,
    output : process.stdout,
    prompt : "$ "
});

const commands = {
    echo : (args)=>{
        console.log(args.join(" ") + "\n");
    },
    pwd : ()=>{
        console.log(process.cwd());
    }
}
let code = 0;


rl.prompt();
rl.on("line", input=>{
    const [cmd, ...args] = input.trim(" ").split(/\s+/);
    switch(cmd){
        case "exit" :
            code = args[0]?parseInt(args[0]):0;
            rl.close(args[0]);
            return;
        default :
            if(commands[cmd]) commands[cmd](args);
            else console.log(`${cmd}: command not found`);
    }
    rl.prompt();
});
    
rl.on("close",()=>{
    console.log("# Shell exits with code "+code);
    rl.removeAllListeners();
    process.exit(0);
});